-- ============================================================
-- EmilInvest: engangsoppsett i NYTT Supabase-prosjekt
-- (nehqvobfwooyufxqbzpv) — kjøres i SQL editor i dashbordet.
--
-- Bakgrunn: databasemigreringen tok bare med public-skjemaet.
-- Storage-bucketen og cron-jobbene ligger i egne skjemaer og
-- må derfor gjenskapes her. Innholdet er hentet fra
-- migrasjonsfilene i repoet (sluttilstand etter alle patcher).
--
-- FØR DU KJØRER: bytt ut {{CRON_SECRET}} nederst med samme
-- verdi som du setter med `supabase secrets set CRON_SECRET=...`
-- ============================================================

-- 1) Utvidelser for planlagte jobber

